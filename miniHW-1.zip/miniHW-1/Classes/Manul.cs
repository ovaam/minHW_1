namespace miniHW_1.Classes;

public class Manul: Animal
{
    public Manul(string name, int age, int food, Thing[] items) : base(name, age, food, items) { }

    public override string GetSpecies()
    {
        return "Manul";
    }
}