namespace miniHW_1.Classes;
using Autofac;

public class Monkey: Herbivore
{
    public Monkey(string name, int age) : base(name, age, 5) { }
}
