﻿using System;
using System.Collections.Generic;
using System.Linq;
using miniHW_1.Classes;
using miniHW_1.Interfaces;

// Интерфейсы
// public interface IAlive { int Food { get; set; } }
// public interface IInventory { int Number { get; set; } }
//
// // Базовый класс Animal
// public class Animal : IAlive, IInventory
// {
//     public string Name { get; set; }
//     public int Age { get; set; }
//     public int Food { get; set; }
//     public int Number { get; set; }
//
//     public Animal(string name, int age, int food)
//     {
//         Name = name;
//         Age = age;
//         Food = food;
//     }
// }
//
// // Травоядные
// public class Herbo : Animal
// {
//     public Herbo(string name, int age, int food) : base(name, age, food) { }
// }
//
// public class Rabbit : Herbo
// {
//     public Rabbit(string name, int age) : base(name, age, 2) { } // Пример: кролик ест 2 кг
// }
//
// // Хищники
// public class Predator : Animal
// {
//     public Predator(string name, int age, int food) : base(name, age, food) { }
// }
//
// public class Tiger : Predator
// {
//     public Tiger(string name, int age) : base(name, age, 10) { } // Пример: тигр ест 10 кг
// }
//
// public class Wolf : Predator
// {
//     public Wolf(string name, int age) : base(name, age, 7) { } // Пример: волк ест 7 кг
// }
//
// // Вещи
// public class Thing : IInventory
// {
//     public string Name { get; set; }
//     public int Number { get; set; }
//
//     public Thing(string name, int number)
//     {
//         Name = name;
//         Number = number;
//     }
// }
//
// public class Table : Thing
// {
//     public Table(int number) : base("Стол", number) { }
// }
//
// public class Computer : Thing
// {
//     public Computer(int number) : base("Компьютер", number) { }
// }
//
// // Зоопарк и ветклиника
// public class Zoo
// {
//     private readonly List<Animal> _animals = new List<Animal>();
//     private readonly VeterinaryClinic _clinic;
//
//     public Zoo(VeterinaryClinic clinic)
//     {
//         _clinic = clinic;
//     }
//
//     public void AddAnimal(Animal animal)
//     {
//         if (_clinic.IsHealthy(animal))
//         {
//             _animals.Add(animal);
//             Console.WriteLine($"{animal.Name} добавлен в зоопарк.");
//         }
//         else
//         {
//             Console.WriteLine($"{animal.Name} не здоров и не может быть добавлен.");
//    

class Program
{
    static void Main(string[] args)
    {
        var clinic = new VetirinaryClinic();
        var zoo = new Zoo(clinic);

        // Добавляем животных
        zoo.AddAnimal(new Rabbit("Кролик", 3, 1));
        zoo.AddAnimal(new Tiger("Тигр", 5, 5));
        zoo.AddAnimal(new Wolf("Волк", 8, 4));

        // Выводим отчеты
        zoo.PrintAnimalReport();
        zoo.PrintContactZooList();
        zoo.PrintInventoryReport();
    }
}
