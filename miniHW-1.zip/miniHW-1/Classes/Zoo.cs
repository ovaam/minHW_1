namespace miniHW_1.Classes;

using System.Collections.Generic;
using System.Linq;

public class Zoo
{
    private readonly List<Animal> _animals = new List<Animal>();
    private readonly VetirinaryClinic _clinic;

    public Zoo(VetirinaryClinic clinic)
    {
        _clinic = clinic;
    }

    public void AddAnimal(Animal animal, int health)
    {
        if (_clinic.CheckHealth(health))
        {
            _animals.Add(animal);
            Console.WriteLine($"{animal.Name} добавлен в зоопарк.");
        }
        else
        {
            Console.WriteLine($"{animal.Name} не здоров и не может быть добавлен.");
        }
    }

    public void PrintAnimalReport()
    {
        Console.WriteLine($"В зоопарке {_animals.Count} животных:");
        foreach (var animal in _animals)
        {
            Console.WriteLine(animal.ToString());
        }

        int totalFood = _animals.Sum(a => a.Food);
        Console.WriteLine($"Общее потребление корма: {totalFood} кг в день.");
    }

    public void PrintContactZooList()
    {
        var contactAnimals = _animals.Where(a => a is Herbivore).ToList();

        if (contactAnimals.Count > 0)
        {
            Console.WriteLine("Животные для контактного зоопарка:");
            foreach (var animal in contactAnimals)
            {
                Console.WriteLine($"- {animal.Name}");
            }
        }
        else
        {
            Console.WriteLine("Нет животных, подходящих для контактного зоопарка.");
        }
    }

    public void PrintInventoryReport()
    {
        foreach (var animal in _animals)
        {
            Thing[] inventoryItems = animal.Items;
            Console.WriteLine("Инвентарь:");
            foreach (var item in inventoryItems)
            {
                if (item != null)
                {
                    Console.WriteLine($"- {item}, owner: {animal.Name}");
                    Console.Write("\n");
                }
            }
        }
    }
}
