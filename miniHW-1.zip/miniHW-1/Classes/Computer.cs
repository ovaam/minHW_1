namespace miniHW_1.Classes;

public class Computer : Thing
{
    public Computer(string name, int number) : base("computer", number) { }
}