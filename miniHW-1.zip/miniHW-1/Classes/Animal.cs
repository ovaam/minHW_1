using miniHW_1.Interfaces;

namespace miniHW_1.Classes;


public class Animal : IAlive, IInventory
{
    public string Name { get; set; }
    public int Age { get; set; }
    public int Food { get; set; }
    public int Number { get; set; }
    public Thing[] Items { get; set; }

    public Animal(string name, int age, int food, Thing[] items)
    {
        Name = name;
        Age = age;
        Food = food;
        Items = items;
    }

    public virtual string GetSpecies()
    {
        return "Generic animal";
    }

    public override string ToString()
    {
        return $"{Name}, возраст: {Age}";
    }

    // public string GetItemsToString()
    // {
    //     string result = "";
    //     foreach (var item in Items)
    //     {
    //         result += $"{item} ";
    //     }
    //
    //     return result;
    // }
}
