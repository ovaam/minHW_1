﻿using miniHW_1.Classes;

class Program
{
    static void Main(string[] args)
    {
        string addingNew = "Желаете ли вы добавить новых живтоных в зоопарк? введите да или нет\n";
        string chooseWhat = "Введите вид животного(кролик/волк/тигр/обезьяна/манул)\n";
        string inputHealth = "Введите степень здоровья животного (10 - отличное, 0 - худшее)\n";
        
        var clinic = new VetirinaryClinic();
        var zoo = new Zoo(clinic);
        
        
        Console.WriteLine(addingNew);
        string input = Console.ReadLine();

        switch (input)
        {
            case "да" or "yes":
            {
                do
                {
                    Console.WriteLine(chooseWhat);
                    var input1 = Console.ReadLine();
                    switch (input1)
                    {
                        case "кролик" or "rabbit":
                        {
                            var animal = AddingAnimals(input1);
                            Console.WriteLine(inputHealth);
                            int health = Convert.ToInt32(Console.ReadLine());
                            zoo.AddAnimal(new Rabbit(animal.Name, animal.Age, animal.Food, animal.Items), health);
                            break;
                        }
                        case "обезьяна" or "monkey":
                        {
                            var animal = AddingAnimals(input1);
                            Console.WriteLine(inputHealth);
                            int health = Convert.ToInt32(Console.ReadLine());
                            zoo.AddAnimal(new Monkey(animal.Name, animal.Age, animal.Food, animal.Items), health);
                            break;
                        }
                        case "волк" or "wolf":
                        {
                            var animal = AddingAnimals(input1);
                            Console.WriteLine(inputHealth);
                            int health = Convert.ToInt32(Console.ReadLine());
                            zoo.AddAnimal(new Wolf(animal.Name, animal.Age, animal.Food, animal.Items), health);
                            break;
                        }
                        case "манул" or "manul":
                        {
                            var animal = AddingAnimals(input1);
                            Console.WriteLine(inputHealth);
                            int health = Convert.ToInt32(Console.ReadLine());
                            zoo.AddAnimal(new Manul(animal.Name, animal.Age, animal.Food, animal.Items), health);
                            break;
                        }
                        case "тигр" or "tiger":
                        {
                            var animal = AddingAnimals(input1);
                            Console.WriteLine(inputHealth);
                            int health = Convert.ToInt32(Console.ReadLine());
                            zoo.AddAnimal(new Tiger(animal.Name, animal.Age, animal.Food, animal.Items), health);
                            break;
                        }
                    }

                    Console.WriteLine("press any key to add more animals or enter to end adding.");
                } while (Console.ReadKey().Key != ConsoleKey.Enter);

                break;
            }
            case "нет" or "no":
            {
                break;
            }
        }
        
        zoo.PrintAnimalReport();
        zoo.PrintContactZooList();
        zoo.PrintInventoryReport();
    }

    static Animal AddingAnimals(string speice)
    {
        string infoAboutName = "Введите имя/кличку животного";
        string infoAboutAge = "Введите возраст";
        string infoAboutFood = "Введите колво потребляемой еды в кг";
        string chooseInventory = "Есть ли инвентарь у вашего животного?\n";
        string inputInventory = "Вводите по очереди весь инвентарь (стол/компьютер/вещь) и количество\n";
        
        Console.WriteLine(infoAboutName);
        string name = Console.ReadLine();
        Console.WriteLine(infoAboutAge);
        int age = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine(infoAboutFood);
        int food = Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine(chooseInventory);
        var input = Console.ReadLine();
        
        Thing[] items = new Thing[10];
        switch (input)
        {
            case "да" or "yes":
            {
                Console.WriteLine(inputInventory);
                items = inputingInventory();
                break;
            }
            case "нет" or "no":
            {
                break;
            }
        }
        var animal = new Animal(name, age, food,items);
        return animal;
    }

    static Thing[] inputingInventory()
    {
        Thing[] inventory = new Thing[10];
        int i = 0;
        do
        {
            Console.WriteLine("введите название предмета: ");
            string name = Console.ReadLine();
            Console.WriteLine("введите количество: ");
            int number = Convert.ToInt32(Console.ReadLine());
            Thing item = null;
            
            switch (name)
            {
                case "компьютер" or "computer":
                {
                    item = new Computer(name, number);
                    break;
                }
                case "стол" or "table":
                {
                    item = new Table(name, number);
                    break;
                }
                case "вещь" or "thing":
                {
                    item = new Thing(name, number);
                    break;
                }
            }
            
            inventory[i] = item;
            i++;
            
            Console.WriteLine("press \"enter\" to exit or any key to continue");
        }
        while (Console.ReadKey().Key != ConsoleKey.Enter);
        
        return inventory;
    }
}
