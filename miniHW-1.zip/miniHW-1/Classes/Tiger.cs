namespace miniHW_1.Classes;

public class Tiger : Predator
{
    public Tiger(string name, int age, int food, Thing[] items) : base(name, age, food, items) { }

    public override string GetSpecies()
    {
        return "Tiger";
    }
}