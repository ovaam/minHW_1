namespace miniHW_1.Classes;

public class Rabbit : Herbivore
{
    public Rabbit(string name, int age, int food, Thing[] items) : base(name, age, food, items) { }
    
    public override string GetSpecies() 
    {
        return "Rabbit";
    }
}

