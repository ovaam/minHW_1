using System.ComponentModel;

namespace miniHW_1.Classes;

// Класс для травоядных животных
public class Herbivore : Animal
{
    public Herbivore(string name, int age, int food, Thing[] items) : base(name, age, food, items) { }

    public override string GetSpecies()
    {
        return "Herbivore";
    }
}
