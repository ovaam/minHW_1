namespace miniHW_1.Interfaces;

public interface IInventory
{
    int Number { get; }
    string Name { get; }
}