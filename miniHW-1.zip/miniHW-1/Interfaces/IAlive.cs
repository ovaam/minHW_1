namespace miniHW_1.Interfaces;

// Интерфейс для живых существ
public interface IAlive
{
    int Food { get; set; }
}