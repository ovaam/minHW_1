namespace miniHW_1.Classes;

public class Rabbit : Herbivore
{
    public Rabbit(string name, int age, int food) : base(name, age, food) { }
    
    public override string GetSpecies() 
    {
        return "Rabbit";
    }
}

