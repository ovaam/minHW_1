using miniHW_1.Interfaces;

namespace miniHW_1.Classes;

public class VetirinaryClinic
{
    public bool CheckHealth(Animal animal)
    {
        // Здесь может быть любая логика проверки здоровья животного
        // Для примера, пусть все животные будут здоровы
        return true;
    }
}