namespace miniHW_1.Classes;

public class Table : Thing
{
    public Table(string name, int number) : base("стол", number) { }
}