using miniHW_1.Interfaces;
using Autofac;
namespace miniHW_1.Classes;

// Класс для зоопарка
using System.Collections.Generic;
using System.Linq;

public class Zoo
{
    private readonly List<Animal> _animals = new List<Animal>();
    private readonly VetirinaryClinic _clinic;

    public Zoo(VetirinaryClinic clinic)
    {
        _clinic = clinic;
    }

    public void AddAnimal(Animal animal)
    {
        if (_clinic.CheckHealth(animal))
        {
            _animals.Add(animal);
            Console.WriteLine($"{animal.Name} добавлен в зоопарк.");
        }
        else
        {
            Console.WriteLine($"{animal.Name} не здоров и не может быть добавлен.");
        }
    }

    public void PrintAnimalReport()
    {
        Console.WriteLine($"В зоопарке {_animals.Count} животных:");
        foreach (var animal in _animals)
        {
            Console.WriteLine($"- {animal.Name} (инв. №{animal.Number})");
        }

        int totalFood = _animals.Sum(a => a.Food);
        Console.WriteLine($"Общее потребление корма: {totalFood} кг в день.");
    }

    public void PrintContactZooList()
    {
        var contactAnimals = _animals.Where(a => a is Herbivore).ToList(); // Все травоядные

        if (contactAnimals.Count > 0)
        {
            Console.WriteLine("Животные для контактного зоопарка:");
            foreach (var animal in contactAnimals)
            {
                Console.WriteLine($"- {animal.Name}");
            }
        }
        else
        {
            Console.WriteLine("Нет животных, подходящих для контактного зоопарка.");
        }
    }

    public void PrintInventoryReport()
    {
        var inventoryItems = new List<IInventory>();
        inventoryItems.AddRange(_animals); // Животные - тоже инвентарь
        inventoryItems.Add(new Table("стол", 0));
        inventoryItems.Add(new Computer("компьютер", 0));

        Console.WriteLine("Инвентарь:");
        foreach (var item in inventoryItems)
        {
            Console.WriteLine($"- {item.GetType().Name} (инв. №{item.Number})");
        }
    }
}
