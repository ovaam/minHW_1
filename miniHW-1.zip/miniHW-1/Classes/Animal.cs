using miniHW_1.Interfaces;

namespace miniHW_1.Classes;

// Базовый класс для животных
public class Animal : IAlive, IInventory
{
    public string Name { get; set; }
    public int Age { get; set; }
    public int Food { get; set; }
    public int Number { get; set; }

    public Animal(string name, int age, int food)
    {
        Name = name;
        Age = age;
        Food = food;
    }

    public virtual string GetSpecies()
    {
        return " Generic animal";
    }
}
