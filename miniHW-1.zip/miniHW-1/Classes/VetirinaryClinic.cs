using miniHW_1.Interfaces;

namespace miniHW_1.Classes;

public class VetirinaryClinic
{
    public bool CheckHealth(int health)
    {
        if (health < 5)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}