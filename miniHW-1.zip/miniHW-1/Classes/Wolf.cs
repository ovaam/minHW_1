namespace miniHW_1.Classes;

public class Wolf : Predator
{
    public Wolf(string name, int age, int food) : base(name, age, food) { }

    public override string GetSpecies()
    {
        return "Wolf";
    }
}