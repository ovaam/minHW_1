namespace miniHW_1.Classes;

public class Tiger : Predator
{
    public Tiger(string name, int age, int food) : base(name, age, food) { }

    public override string GetSpecies()
    {
        return "Tiger";
    }
}