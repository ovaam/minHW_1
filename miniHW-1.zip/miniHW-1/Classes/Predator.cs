namespace miniHW_1.Classes;

public class Predator: Animal
{
    public Predator(string name, int age, int food) : base(name, age, food) { }

    public override string GetSpecies()
    {
        return "Predator";
    }
}