namespace miniHW_1.Classes;
using Autofac;

public class Monkey: Herbivore
{
    public Monkey(string name, int age, int food, Thing[] items) : base(name, age, food, items) { }
}
