using System.ComponentModel;

namespace miniHW_1.Classes;

// Класс для травоядных животных
public class Herbivore : Animal
{
    public Herbivore(string name, int age, int food) : base(name, age, food) { }

    public override string GetSpecies()
    {
        return "Herbivore";
    }
}
