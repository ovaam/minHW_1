namespace miniHW_1.Classes;

public class Wolf : Predator
{
    public Wolf(string name, int age, int food, Thing[] items) : base(name, age, food, items) { }

    public override string GetSpecies()
    {
        return "Wolf";
    }
}